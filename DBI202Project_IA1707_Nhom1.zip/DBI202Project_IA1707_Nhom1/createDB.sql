﻿create database [Quản Lý Nhân Sự]
create table [Nhân Sự](
	[Họ Tên] nvarchar(50),
	[Mã NS] char(4) primary key, 
	[Giới Tính] nvarchar(10),
	[Ngày Sinh] date,
	[Dân Tộc] nvarchar(20),
	[Quê Quán] nvarchar(50),
	[Số Điện Thoại] char(11)
)

create table [Lương](
	[Bậc Lương] float primary key,
	[Lương CB] float,
	[HS Lương] float,
	[HS phụ cấp] float
)
create table [Trình Độ Học Vấn](
 MaTDHV char(6) primary key,
 [Tên TDHV] nvarchar(50),
 [Chuyên Ngành] nvarchar(50)
)

create table [Phòng Ban](
	MaPB char(3) primary key, 
	[Tên PB] nvarchar(50),
	[SĐT PB] char(11)
)
create table [Chức Vụ](
	MaCV char(4) primary key,
	[Tên CV] nvarchar(50)
)

create table [Hợp Đồng Lao Động](
	MaHD char(4) primary key,
	LoaiHD nvarchar(15),
	TuNgay Date,
	DenNgay Date,
	MaCV char(4) references [Chức Vụ](MaCV),
	MaPB char(3) references [Phòng Ban](MaPB),
	BacLuong float references [Lương]([Bậc Lương])
)
create table [Có](
MaNS char(4) references [Nhân Sự]([Mã NS]),
MaHD char(4) references [Hợp Đồng Lao Động](MaHD),
primary key (MaNS,MaHD)
)
create table [Đạt](
[Mã NS] char(4) references [Nhân Sự]([Mã NS]),
MaTDHV char(6) references [Trình Độ Học Vấn](MaTDHV),
primary key([Mã NS],MaTDHV)
)