﻿--trigger: update Lương và Phòng Ban, hiển thị thông tin vừa update
create trigger UpdateLuongAndPhongBan
on [Hợp Đồng Lao Động]
for update 
as
Begin
  If update(BacLuong) or update(MaPB)
  begin
	select deleted.MaHD, BacLuongCu=deleted.BacLuong,
	BacLuongMoi=inserted.BacLuong, PBcu=deleted.MaPB, PBmoi=inserted.MaPB
	from inserted join deleted
	 on inserted.MaHD=deleted.MaHD
  end
end
Update [Hợp Đồng Lao Động]
set BacLuong=6
where MaHD='HD01'