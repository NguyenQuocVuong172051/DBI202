﻿--procedure Luong, tham số đầu vào là bậc lương, tham số đầu ra là lương nhận được

create proc Luong  @BacLuong float, @TongLuong float output
as
begin 
	select @TongLuong=[Lương CB]*([HS Lương]+[HS phụ cấp])
	from [Lương]
	where @BacLuong =[Bậc Lương]
end

declare @TongLuong float
exec Luong 1, @TongLuong output
select @TongLuong AS Luong