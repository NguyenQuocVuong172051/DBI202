﻿--1. Tìm những nhân sự có Quê Quán ở Hà Nội
select * from [Nhân Sự] as NS
where NS.[Quê Quán] =N'Hà Nội'

-- 2. Tìm những hợp đồng có thời hạn có thời hạn nhiều hơn 3 năm
select* from [Hợp Đồng Lao Động] as HD
where YEAR(HD.DenNgay)-YEAR(HD.TuNgay)> 3 and HD.LoaiHD = N'Có thời hạn'

--3. Tìm nhân sự được ký hợp đồng với mức lương cao nhất
select NS.[Họ Tên], NS.[Mã NS], NS.[Giới Tính], NS.[Giới Tính], NS.[Ngày Sinh], NS.[Dân Tộc],NS.[Quê Quán], NS.[Số Điện Thoại]
from [Nhân Sự] as NS
join [Có] as C on C.MaNS = NS.[Mã NS]
join [Hợp Đồng Lao Động] as HD on C.MaHD = HD.MaHD
where HD.BacLuong = 
(select MAX(HD.BacLuong) from [Nhân Sự] as NS
join [Có] as C on C.MaNS = NS.[Mã NS]
join [Hợp Đồng Lao Động] as HD on C.MaHD = HD.MaHD)

--4. Tìm nhân sự có 2 trình độ học vấn trở lên ký hợp đồng có mức lương bậc 5
select * from [Nhân Sự] as NS
where NS.[Mã NS] in
(select distinct NS.[Mã NS] from [Nhân Sự] as NS
join Có as C on C.MaNS = NS.[Mã NS]
join [Hợp Đồng Lao Động] as HD on HD.MaHD = C.MaHD
where HD.BacLuong = 5 
intersect
select D.[Mã NS] from Đạt as D
group by D.[Mã NS]
Having COUNT(D.MaTDHV)>=2)

--5. Tìm những Chức vụ chưa ký trong Hợp đồng lao động
select * from [Chức Vụ] as CV
where CV.MaCV in
(select CV.MaCV from [Chức Vụ] as CV
left join [Hợp Đồng Lao Động] as HD on CV.MaCV = HD.MaCV
where HD.MaHD is null)

-- 6. Hiển thị Mã NS, Họ tên và lương của nhân sự ở phòng ban P02 
--với công thức lương = (bậc lương+hệ số phụ cấp)*luongCB
select NS.[Mã NS], NS.[Họ Tên] , (L.[Bậc Lương]+L.[HS phụ cấp])*L.[Lương CB] as LuongNV
from [Nhân Sự] as NS
join Có as C on C.MaNS = NS.[Mã NS]
join [Hợp Đồng Lao Động] as HD on HD.MaHD = C.MaHD
join Lương as L on L.[Bậc Lương] = HD.BacLuong
where HD.MaPB = 'P02'

-- 7. Tính lương trung bình của mỗi phòng ban
select PB.MaPB as [Mã PB], PB.[Tên PB],
AVG((L.[Bậc Lương]+L.[HS phụ cấp])*L.[Lương CB]) as [Lương TB] 
from [Phòng Ban] as PB
join [Hợp Đồng Lao Động] as HD on HD.MaPB = PB.MaPB
join Lương as L on L.[Bậc Lương] = HD.BacLuong
group by PB.MaPB, PB.[Tên PB]

