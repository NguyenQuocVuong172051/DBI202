﻿-- ngày sinh phải là ngày trong quá khứ
alter table [Nhân Sự]
add constraint Ck_Birth check ([Ngày Sinh]<getDate())

--Giới tính phải là Nam hoặc Nữ
alter table [Nhân Sự]
add constraint CK_GioiTinh check ([Giới Tính] = N'Nam' or [Giới Tính] = N'Nữ')
select *
from [Nhân Sự]
--Ngày bắt đầu hợp đồng < ngày kết thúc hợp đồng
alter table [Hợp Đồng Lao Động]
add constraint Ck_date check (TuNgay<DenNgay)