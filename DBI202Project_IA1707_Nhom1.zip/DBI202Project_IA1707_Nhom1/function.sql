﻿--Hàm in ra dang sách nhân sự
create function UF_danhSachNS()
returns table
as return select * from [Nhân Sự]